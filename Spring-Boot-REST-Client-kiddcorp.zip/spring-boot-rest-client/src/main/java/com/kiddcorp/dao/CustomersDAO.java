package com.kiddcorp.dao;

import java.util.Collection;

import com.kiddcorp.domain.Customer;

public interface CustomersDAO {
	public Collection<Customer> getAllCustomers();
}
